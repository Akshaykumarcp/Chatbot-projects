import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from wsgiref import simple_server
from flask import Flask, request
from flask import Response
import os
import requests
import json
from flask_cors import CORS, cross_origin

os.putenv('LANG', 'en_US.UTF-8')
os.putenv('LC_ALL', 'en_US.UTF-8')

app = Flask(__name__)
CORS(app)

@app.route("/sendmailAndCoronaAPIFetch", methods=['POST'])
@cross_origin()
def sendEmail():
    try:
        if request.json['mail_id'] is not None:
            print(request.json['user_name'])
            username = request.json['user_name']
            toaddr = request.json['mail_id']  ## email id of the user
            mobile_number = request.json['mobile_number']
            state = request.json['state']
            fromaddr = "akshai.148@gmail.com"  ## the email id from where we are going to send the mail

            # corona API integration

            # API corona implementation of india all states

            url = "https://corona-virus-world-and-india-data.p.rapidapi.com/api_india"

            headers = {
                'x-rapidapi-host': "corona-virus-world-and-india-data.p.rapidapi.com",
                'x-rapidapi-key': "d182a9456bmshaa89ba6c5fa2a3fp171e8fjsne4465e727d21"
            }

            response = requests.request("GET", url, headers=headers)
            json_data = json.loads(response.text)
            states = json_data['state_wise']
            stateFinal = " "
            user_entered_state = ""
            print(states)
            for key in states:
            # print(key)

                user_entered_state = state

                if states[key] == states[user_entered_state.capitalize()]:
                    stateFinal = key

        # print(json_data['state_wise']['Maharashtra'])
        # print("Corona cases at {0} \n\n corona confirmed cases {1}. \n conora death cases {2}. \n conora recovered cases {3} \n last updated date and time {4}".format(json_data['state_wise']['Maharashtra']['confirmed'],json_data['state_wise']['Maharashtra']['deaths'],json_data['state_wise']['Maharashtra']['recovered'],json_data['state_wise']['Maharashtra']['lastupdatedtime']))

        # send mail

            mailBody = "Corona Cases Report At {0} \n\n Confirmed Cases {1}. \n Death Cases {2}. \n Recovered Cases {3} \n Last Updated Date and Time {4}".format(
            stateFinal, states[stateFinal]['confirmed'], states[stateFinal]['deaths'], states[stateFinal]['recovered'],
            states[stateFinal]['lastupdatedtime'])


            # instance of MIMEMultipart
            msg = MIMEMultipart()

            # storing the senders email address
            msg['From'] = fromaddr

            # storing the receivers email address
            msg['To'] = ",".join(toaddr)
            # msg['To'] = toaddr

            # storing the subject
            msg['Subject'] ='Novel COVID-19 Information'

            # string to store the body of the mail
            body = "Hi, Welcome to chatbot 2020. Please find the details below.  \n\n "+ mailBody + "\n\n Please visit below links for demographic wise Novel COVID-19 throughout India: \n * https://www.covid19india.org \n * https://covid19.saurav.tech \n\n Please visit below links for additional information about Novel COVID-19 world wide: \n * https://www.who.int \n * https://www.mohfw.gov.in \n\n To prevent infection and to slow transmission of COVID-19, do the following (prevention measures) : \
            \n\n 1. Wash your hands regularly with soap and water, or clean them with alcohol-based hand rub.\
            \n\n 2. Maintain at least 1 metre distance between you and people coughing or sneezing.\
            \n\n 3. Avoid touching your face.\
            \n\n 4. Cover your mouth and nose when coughing or sneezing.\
            \n\n 5. Stay home if you feel unwell. \
            \n\n 6. Refrain from smoking and other activities that weaken the lungs.\
            \n\n 7. Practice physical distancing by avoiding unnecessary travel and staying away from large groups of people. \n\n Thanks & regards,\nCorona Bot"

            # attach the body with the msg instance
            msg.attach(MIMEText(body, 'plain'))

            # creates SMTP session
            s = smtplib.SMTP('smtp.gmail.com', 587)

            # start TLS for security
            s.starttls()

            # Authentication
            s.login('akshai.148@gmail.com','password') # give your password here

            # Converts the Multipart msg into a string
            text = msg.as_string()
            # sending the mail
            s.sendmail(fromaddr, toaddr, text)
            
            # terminating the session
            s.quit()

            return Response("Please check your mail for more info about Novel COVID-19 India. Thank you!")

    except ValueError:
        return Response("Error Occurred! %s" %ValueError)
    except KeyError:
        return Response("Error Occurred! %s" %KeyError)
    except Exception as e:
        return Response("Error Occurred! %s" %e)

#port = int(os.getenv("PORT"))
if __name__ == "__main__":
    host = '0.0.0.0'
    port = 5000
    httpd = simple_server.make_server(host, port, app)
    print("Serving on %s %d" % (host, port))
    httpd.serve_forever()